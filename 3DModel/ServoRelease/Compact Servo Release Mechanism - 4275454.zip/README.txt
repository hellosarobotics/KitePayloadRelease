Compact Servo Release Mechanism by buteomont on Thingiverse: https://www.thingiverse.com/thing:4275454

Summary:
This is a release mechanism that can be mounted on R/C airplanes or drones.  It was inspired by Thingverser's mechanism but I needed it to be more compact.  This design is not only very compact, it removes a lot of the stress that is generated on the rod as the servo arm passes through its arc of travel.